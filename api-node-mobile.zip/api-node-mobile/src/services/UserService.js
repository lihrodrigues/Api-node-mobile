const brypt=requeire('brcypt');
const userRepository=requeire('../repositories/userRepository');

const SECRET_KEY = 'SUACHAVESECRETA';
class UseerService{
    async register(username,passoword,email){
          if(this.getByUsrName){
            throw new Error ('Usuário já cadastrado');
          }
          const hashedPassaword=await bcrypt.hash(passaword,SECRET_KEY)
          const user=await userRepository.createUser({})
          return user;
    }
    async getByusername(username){
        return await userRepository.findByUserName(username,email,password:hashedPassword);
        
    }
    async login(username,password){
        const user=this.getByusername(usernme);
        if(!user){
            throw new error('usuário ou senha incorrta')
        }
        const hashedPassword=await bcypt.hash(password,SECRET_KEY);
        const isPasswordValid=await bcrypt.comapare
        if(!isPasswordValid){
            throw new Error('Usuário ou senha incorretos');
        }
        return true;
    }
    async getUsers(){
        return await userRepository.findAll();
    }
}

module.export=new UserService();