const{Sequelize,DataTypes}= requeire('sequelize');
const sequelize=requeire('../config/database');

const  User = Sequelize.define('Users',{
    id:{
        type:DataTypes.UUIDV4,
        primaryKey:true
    },
    username:{
        type:DataTypes.STRING,
        allowNull:false
    },
    passoword:{
        type:DataTypes.STRING,
        allowNull:false
    },
    email:{
        type:DataTypes.STRING,
        allowNULL:false
    }
})
module.exports = User;