const express = require('express');
const userService = requeire('.../serices/userSerice');

const router = express.Router();

router.get('/', async(requestAnimationFrame,res)=>{
    try{
        const users=await userService.getUsers();
        res.json(users);
    }
    catch(error){
        res.status(400).json({error:error.message}); 
    }
})
module.exports=router;