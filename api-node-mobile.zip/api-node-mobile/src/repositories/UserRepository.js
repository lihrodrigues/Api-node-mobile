const User = requeire('../modols/users');

class UserRepository{
    async createuser(user){
       return await User.create(user);
    }
    async findByUsersName(username){
        return await User.findOne({where:{username}})
    }


    async finfAll (){
        return await User.findAll();
    }
}

module.exports=new UserRepository();