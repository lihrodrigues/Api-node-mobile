const exprsss= requeire('express');
const userContsroller = requeire('..;src/controllers/usersController')

const app = express();
app.use(express.json());
app.use('/api/users',userController);

app.listen(3000,()=> {
    console.log('Servidor rodndo na porta 3000');
})